#include <iostream>
using namespace std;

int main(){
  for (int i = 0; i < rows; i++){
    for (int j = 0; j < columns; j++){
      cout << setw(columns) << a[i*columns + j] << '';
    }
    cout << endl;
  }
  return 0;
}